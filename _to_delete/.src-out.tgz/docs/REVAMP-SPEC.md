# Portfolio Revamp — Spec

Status: decisions locked, ready for Design.
Owner: Spencer Bowden. Last updated: 2026-08-10.

This is the source of truth. `docs/DESIGN-BRIEF.md` is what gets handed to Claude Design;
`docs/TODO.md` is what gets handed to Claude Code. Both derive from this file.

---

## 1. Decisions locked

| Question | Decision |
|---|---|
| Nav model | One neutral bar on every page. Section color enters only through the active-link underline. |
| Skill tree | Keep the node graph. Restructure into vertical specialty lanes, wrapped 3-up. |
| v1 scope | Landing, Résumé, Contact, Musical. Technical ships with a restructured but static skill tree. Pixel animation and playable instruments are v2. |
| Two portfolios | Yes — Technical and Musical stay visually distinct, but the distinction lives in the page content, not the chrome. |

---

## 2. Information architecture

```
/                 Landing — hero, short bio, four entry points
/technical        About → Projects → Skills          (tabs, in that order)
/musical          About → Credits → Mainstage Files  (tabs, in that order)
/resume           Viewer + download
/contact          Info cards + form
```

Both section orders are reversed from today. Technical currently opens on the skill
tree; it should open on About and end on Skills, so the fun thing is a payoff rather
than a cold open. Musical currently has a dead `training` tab wired to a two-value
`useState` while rendering three buttons — that's a live bug, the About button does
nothing.

### Navigation

A single `<SiteNav>` component, sticky, ~56px, identical on every route.

- Background `--ink` (#242038) everywhere. Deliberately detached from the page
  background so it reads as a fixed layer.
- Wordmark left ("Spencer Bowden"), five links right: Home, Technical, Musical,
  Résumé, Contact. Same order everywhere.
- Active link: white text + 3px underline in that section's accent. That underline is
  the *only* place section color appears in the chrome.
- Takes one prop: `accent`. Nothing else varies.
- Mobile: wordmark + menu button, slide-down panel. No emoji — Tabler outline or a
  hand-made pixel glyph.

All five "← Back to Home" links are deleted; the wordmark replaces them.

Section tabs (About / Projects / Skills, etc.) sit *below* the bar and are styled per
section. Two tiers: global chrome on top, local navigation beneath.

---

## 3. Design tokens

Tailwind v4 has no `tailwind.config.ts`. Custom colors go in an `@theme` block in
`app/globals.css`. This is the whole palette — nothing outside it.

### Color

**shadcn/ui's `init` appended its own neutral `oklch()` palette to `globals.css`**
(`--primary`, `--accent`, `--border`, `--sidebar-*`, a `.dark` block, etc). That palette
is scaffolding, not design — never the source of a visible color. If a shadcn component
is used anywhere, override its default classes with the tokens below (a shadcn `Button`
gets `bg-tech`, not `bg-primary`). See the comment above the `@theme` block in
`globals.css` for the long version.

```css
@theme {
  /* Structure */
  --color-ink:          #242038;  /* primary text, nav background */
  --color-ink-soft:     #4A4260;  /* secondary text */
  --color-paper:        #CAC4CE;  /* landing / resume / contact background */
  --color-paper-warm:   #F4F1E8;  /* musical background */
  --color-surface:      #FFFFFF;  /* cards */

  /* Section accents — used for the nav underline and within each page */
  --color-tech:         #9067C6;
  --color-tech-soft:    #8D86C9;
  --color-tech-bright:  #AC8DD4;  /* text-safe on dark */
  --color-music:        #87BFA5;
  --color-music-deep:   #3E7A62;  /* text-safe on light */
  --color-resume:       #FFD76A;
  --color-resume-deep:  #8A6A0B;  /* text-safe on light */
  --color-contact:      #B56C8C;
  --color-contact-deep: #9E5677;
}
```

Three cleanups baked into that list:

1. **The background was two colors.** Landing uses `#CAC4CE`, every other page uses
   `#CAC6CE`. One character apart, almost certainly a typo. Unified to `#CAC4CE`.
2. **Musical has two unrelated greens.** The landing button is mint `#87BFA5`, but the
   Musical page itself uses `#1b5e20` / `#4caf50` — those are stock Material greens and
   they clash with the rest of the palette. Musical is now derived from the mint.
3. **`-deep` variants exist for contrast.** `#FFD76A` and `#87BFA5` both fail WCAG AA as
   text on white. Use the base color for fills and borders, the `-deep` variant whenever
   the color carries text.
4. **`--color-tech-bright` is the same idea inverted — added 2026-08-13.** Technical is the
   one dark room in the house, so `--tech` needed the opposite partner: a `-deep` would
   have sunk into the ground. A contrast audit found `--tech` failing AA at nine sites on
   its own page — 3.69:1 as text on `--ink`, 4.09:1 on `--ink-deep`, and 4.25:1 for white
   on a `--tech` fill, so *neither* foreground worked over it. The rule on Technical is
   now: **`--tech` for borders, spines and decoration; never for type and never behind
   type.** Anything carrying text uses `-bright` (5.61:1 on `--ink`, 6.21:1 on
   `--ink-deep`), and a `-bright` fill takes `--ink` on top, which is the same
   ink-on-accent rule `components/ui/button.tsx` already followed. One token covered all
   nine sites; a `--color-tech-deep` was drafted and proved unnecessary.

### Type

Two base families plus two section display faces. Never the same face for heading and
body on any given page.

```css
--font-sans:    Atkinson Hyperlegible Next
                                  /* body, everywhere. Replaced Geist 2026-08-12 —
                                     Geist was the create-next-app default, i.e. the one
                                     face nobody chose. Braille Institute low-vision
                                     family: I/l/1 and 0/O drawn apart, asymmetric bowls,
                                     open apertures. Half the degree is Cognitive Studies
                                     and these guardrails are already about legibility,
                                     so the face states a position. ~4% wider than Geist. */
--font-display: Fraunces          /* landing, résumé, contact headings */
--font-mono:    Atkinson Hyperlegible Mono
                                  /* technical body + UI. Same family as the body face,
                                     so the two read as one decision. */
--font-pixel:   Press Start 2P    /* technical H1 and skill-tree labels only. PxlKit's
                                     own pixel face (PXLKIT_FONTS) — changed from
                                     Silkscreen 2026-08-12 so the type matches the icons.
                                     Roughly 2x Silkscreen's advance width, so pixel type
                                     is sized well below --text-display. */
--font-score:   Cormorant Garamond /* musical headings */
```

Both Atkinson faces carry `adjustFontFallback: false` and a fallback stack of their own.
Next builds its metric-matched fallback `@font-face` from a precalculated table
(`next/dist/server/capsize-font-metrics.json`), and these two families are newer than it —
the table holds `atkinsonHyperlegible` but neither `Next` nor `Mono`. The lookup threw,
Next logged "Failed to find font override values" on every compile, and returned
`undefined` anyway. Opting out changes nothing about the emitted CSS; it only stops asking
for a fallback that cannot be built. Drop the two lines once the families reach the table.

Large headings get `letter-spacing: -0.03em`. Body copy gets `line-height: 1.7`.
Georgia and `font-family: monospace` are currently hardcoded inline in five files —
all of it moves into tokens.

### Spacing and depth

Use a 4px-based scale and stick to it: `4 8 12 16 24 32 48 64 96`. Current code mixes
`p-6`, `mt-12`, `mb-16`, `gap-10` with no system.

Three surface levels: `paper` (page) → `surface` (card) → floating (modal, tooltip).
Shadows are color-tinted and low-opacity, never flat `shadow-md`.

---

## 4. Library decisions

| Need | Choice | Notes |
|---|---|---|
| Base components | **shadcn/ui** | Copy-paste, not a dependency. Works with Tailwind v4 + React 19. Used on landing, résumé, contact, musical. |
| Technical aesthetic | **PxlKit** (`@pxlkit/core` + `@pxlkit/ui-kit` + `@pxlkit/parallax`) — INSTALLED | v2.1.1, TypeScript, built for Tailwind v4, documents its Next.js setup. 111 components, 226 icons. Also publishes Claude Code skills at pxlkit.xyz/skills. |
| Icons | **Tabler outline** + PxlKit icons on Technical | No emoji anywhere. See §7. |
| Audio (v2) | **Tone.js + smplr** | *Not* react-orchestra — see below. |
| Contact form | **Web3Forms** | 250 submissions/month free. See §6. |
| Fonts | **next/font** (Google) | Already the pattern in `layout.tsx`. |

### react-orchestra is not viable

Your doc names it twice. It was last published around 2017, predates hooks, and will
not run on React 19. Use `tone` for the audio graph and `smplr` for sampled instruments
— `smplr` is the maintained successor to `soundfont-player`, ships a `SplendidGrandPiano`,
and streams samples from a CDN so no audio files live in the repo. Same end result:
click an instrument in the sidebar, hear a snippet.

### PxlKit licensing — CLEARED

Confirmed free to use. Source: https://github.com/joangeldelarosa/pxlkit — code packages
MIT, icon packs free with attribution. Add the attribution line to the site footer or
README when the packs go in.

### Two component libraries is fine

shadcn is copied source, not an npm dependency, so pairing it with PxlKit costs nothing
in bundle size and creates no version conflict. Keep the boundary clean: PxlKit only
inside `/technical`.

### Why `<PixelSprite>` exists rather than PxlKit's own renderers

Confirmed against the vendor docs at pxlkit.xyz/docs 2026-08-13: neither
`<AnimatedPxlKitIcon>` nor `<ParallaxPxlKitIcon>` mentions `prefers-reduced-motion`, and
neither reads it. `ParallaxPxlKitIcon` also tracks the mouse page-wide rather than within
its own container, and ships a peel-apart mount animation, click particle bursts, and a
hue-shift on activate. On a page that already leans on float and pulse, that is motion this
site cannot switch off. `<PixelSprite>` draws the same icon *data* on a canvas and holds at
frame 0 under reduced motion.

Two things worth taking from their implementation if the sprites are ever revisited: they
lerp pointer tracking (`smoothing`, default 0.06) where ours snaps, and they expose an
`appearance` prop (`palette | tinted | solid`) with a `color`, which is how an off-palette
icon gets pulled onto a project's palette. There is no exported helper for it — the
transform lives inside their components as an SVG filter — but `solid` is a palette
override and reproducible in `PixelSprite` in a few lines.

---

## 5. Bugs in the current build

Found by inspecting `out/`. These are real and shipping today.

### Every image 404s in production — RESOLVED 2026-08-10

`next.config.ts` set `basePath: "/spencerbowden.github.io"` in production. Next prefixes
its own JS and CSS but does **not** prefix raw `<img src="/...">`. The built
`out/index.html` contained:

```
href="/spencerbowden.github.io/_next/static/chunks/....css"   ← prefixed
src="/images/me.jpg"                                          ← not prefixed
src="/SWB_RESUME_Tech.pdf"                                    ← not prefixed
```

Broken in production: the portrait, all four hover icons, all 40+ skill-tree logos, the
sprite, the résumé iframe, and the résumé download button.

**Fixed.** The repo is now `bowdensw/bowdensw.github.io` — a GitHub *user* page served at
the domain root. `basePath` and `assetPrefix` have been deleted from `next.config.ts`.
Root-relative asset paths are now correct as written, and no `withBasePath()` helper is
needed. Do not reintroduce either setting.

Still to verify locally: `npm run build` clean, and GitHub Pages' source branch set
correctly for a user page (the `deploy` script pushes to `gh-pages` via the `gh-pages`
package — confirm Settings → Pages points at that branch, not `main`).

### Three images that never existed

`app/page.tsx` references `/icons/code.png`, `/icons/music.png`, `/icons/book.png`.
There is no `public/icons/` directory. Broken in dev too.

### The Musical About tab is dead

`app/musical/page.tsx` renders three buttons but types state as `"shows" | "training"`.
Clicking About sets an out-of-range value and renders nothing.

### The contact form does not send

`handleSubmit` calls `alert("Message sent! (Demo)")`. Because `output: "export"` is set,
there are no API routes and no server actions available — a form backend is mandatory,
not optional.

### Dead and empty files — RESOLVED 2026-08-10

Deleted:

- `app/technical/components/about.tsx` — 0 bytes
- `app/technical/components/AttributePanel.tsx` — 0 bytes
- `app/technical/components/attributes.tsx` — 292 lines, imported by nothing, emoji-laden

**Correction:** `techIcons.tsx` was listed here in error. It is imported by
`Projects.tsx` (`getTechIcon`) and is live code. Kept.

The About copy that should live in `about.tsx` is still inlined in `page.tsx` — move it
during Phase 6.

### Emoji in the codebase

The skill tree H1 is literally `SKILL TREE🛠️`, and `attributes.tsx` uses 🧩 ⚔️ 🧠 ⚙️ 🌐.
Violates the project's own hard rule.

---

## 6. Per-page requirements

### Landing

- shadcn portfolio-style layout. Hero, short bio, four entry points.
- Keep the hover-icon idea — it has personality and it's yours. Fix the assets, keep the
  float animation, add `prefers-reduced-motion` handling.
- New favicon: yellow backpack, replacing the penguin. **Shipped 2026-08-12.** Kanken
  silhouette on a 16×16 pixel grid, body `#FFD76A` / `#F0C24F` over `#8A6A0B`
  (`--color-resume` and `--color-resume-deep`), straps `#6E442B` / `#9C6644`, buckle
  `#F4F1E8`. The straps came out a shade deeper than the `#8C6E4F` in the decision log —
  Spencer's art wins.

  The three files live in `app/`, not `public/`, using Next's metadata file convention:
  `app/favicon.ico` (48px), `app/icon.svg`, `app/apple-icon.png` (180px). Next evaluates
  them and emits the `<link>` tags itself with content hashes, which is why there are no
  hand-written icon tags in the layout and no `public/` path to keep in sync. Browsers
  that understand SVG take `icon.svg` and get a crisp icon at any size; the rest fall
  back to the `.ico`.
- Bio copy: supplied and in place.

### Technical

Tab order: **About → Projects → Skills.**

Skill tree, restructured:

- Six vertical lanes by specialty — Foundations, Front End, Back End,
  Systems / Game Design, Academic / Research, UI / UX. They wrap 3-up rather than
  scrolling horizontally: six lanes never fit on one row, and a column cut off mid-node
  reads as broken rather than as "there is more".
- Lanes and nodes mirror the Claude Design skill-tree mockup exactly, down to each
  node's tier and the course or project credited beneath it.
- Progress reads top-to-bottom *within* a lane. Foundations at the top, advanced work at
  the bottom. The current graph has everything cross-connected, which is why it reads as
  noise to anyone who hasn't played FFX.
- Kill the multi-radial-gradient backdrop. Flat dark surface, or a subtle pixel grid.
- **Tooltips carry how and why, not what.** "React" shouldn't say "a JavaScript library."
  It should say where you used it and what it let you build. This is the highest-value
  change on the page and it's a writing job, not a code job — budget real time for it.
  Every node needs 1–2 sentences from you.
- Node data moves from hardcoded `x`/`y` pixel coordinates to lane + tier indices, with
  layout computed. The current 459-line `skills.tsx` is unmaintainable as absolute
  positions.
- Each lane heads with one animated sprite, mapped in `app/technical/data/pixel.ts`.
  **Revised 2026-08-13**: the first three are hand-drawn in `app/technical/data/icons/`
  and say what the lane *is* rather than decorating it — Foundations is four puzzle pieces
  locking together and coming apart, Front End is React's orbit with an electron running
  the track, Back End is a terminal, a database and a gear. Systems / Game Design keeps
  `RetroJoystick`, Academic / Research `SparkBurst`, UI / UX `PixelHeart`, because a
  joystick, a spark and a heart already read as the thing.
- The Foundations puzzle is the one icon that uses the **site** palette rather than the
  Technical ramp: its four pieces are the four section accents (Musical, Contact,
  Technical, Résumé). The lane is about the parts a whole is assembled from, and those are
  the parts of this site. All four clear 4:1 on `--color-ink-deep`; gold clears 12.6:1.
- React's orbit is **walked, not drawn**. The ellipse is sampled into an ordered ring of
  pixels, so the electron's position is an index into that ring and cannot drift off the
  track; widening the ellipse moves the particle with it.
- Two source shapes arrive at `toLayers()`: `@pxlkit/parallax` stacks layers for
  mouse-tracked depth, while the flat packs and all three hand-drawn lane icons ship one
  icon. It treats a flat icon as a one-layer stack at depth 0. Every icon in use is 16×16.
- Lane sprites render at **36px** (`size-9`), up from 28px. The Back End icon carries three
  objects in one grid and below about 36px they stop resolving as three things.
- Pixel art: sprite of you at a computer, replacing the walking sprite. **v2** — multi-state
  animation (coding → debugging → writing → head-against-wall → going to play music).
  v1 ships one idle state.
- Header sprites, **replaced 2026-08-13**: MagicOrb and RetroTV out, a desk computer on the
  left and a two-grip gamepad on the right — the work, and the reason for it. Both are
  hand-drawn in `app/technical/data/icons/` because PxlKit ships neither shape among its
  226 icons, and because its own art comes in the pack's grey-and-green retro palette rather
  than this page's purple. Same five-layer stack and depth ladder (3 / 2 / 0 / -1 / -2) as
  the parallax pack, so they render through the existing `toLayers()` path unchanged.
  Colours come from `icons/palette.ts`, which mirrors the `@theme` tokens by hand — the
  icon format takes literal hex and a CSS variable cannot reach into it.
- Shading ramp, **added 2026-08-13**. The first cut was flat fills, one value per surface.
  The ramp now has two arms off a shared base: the warm arm walks `--color-tech` toward
  `--color-ink` for form shadow (`#BAA2DA → #9067C6 → #70529B → #58427C`), and the cool arm
  hue-shifts `--color-tech-soft` into indigo and blue (`#9BA6EC → #6578E7 → #4F5AAC →
  #34386E`). Only the six anchors are tokens; the rest are interpolations between them, so
  the ramp cannot drift off-palette. Light falls from the top left on both icons — lit
  values on top and left edges, shadow on bottom and right — and the blue arm is reserved
  for things that emit rather than reflect: the screen, a lit face button, the ambient
  motes, and the recessed D-pad that catches only cool bounce.

### Musical

Tab order: **About → Credits → Mainstage Files.**

- About: the bio from your planning doc goes in verbatim, plus the "other notable gigs"
  line. Break into two or three paragraphs.
- Credits (formerly "Shows"): compact rows, not the current two-column card grid.
  Columns are Production / Year / Role / Company / Credit, ordered newest first and
  hand-ordered within a year. A credit can wear more than one hat, so each department
  the role touches adds its own glyph. Optional row/grid toggle is v2.
- Mainstage Files: new tab, Production / Price / request, alphabetical by title (sorted
  in the data so it stays that way). Your sales copy goes in verbatim, base price $300/show,
  contact `spencerbowden337@gmail.com`. **You have no files yet** — this needs a real
  empty state that reads as "coming soon," not as a broken page.
- Instruments in the sidebar playing show snippets: **v2**, via Tone.js + smplr.
  Note you'll need rights-cleared audio — recordings of yourself, not cast albums.

### Résumé

- shadcn shell, keep the yellow.
- The `<iframe src="/resume.pdf">` is a poor mobile experience — iOS Safari often won't
  render it. Add a visible download fallback and consider a rendered HTML version as the
  primary view with the PDF as the download.

### Contact

- shadcn form. Wire to Web3Forms. Test end-to-end with a real send.
- Click-to-copy on every value — email, phone, GitHub, LinkedIn. Copy icon, "Copied"
  confirmation, `navigator.clipboard`.
- GitHub and LinkedIn also get direct-link buttons ("Open in GitHub").
- Honeypot field for spam. hCaptcha is available free if it becomes a problem.

---

## 7. Standing rules

- **Never any emoji.** Icons are Tabler outline, PxlKit pixel icons, or hand-made SVG.
- No default Tailwind palette colors. The `@theme` block above is the whole palette.
- Never `transition-all`. Animate `transform` and `opacity` only.
- Every interactive element needs hover, `focus-visible`, and active states.
- Respect `prefers-reduced-motion` — the site leans on float and pulse animations.
- Mobile-first. The skill tree in particular has no mobile story today.
- Keep `output: "export"` compatible. No server actions, no API routes, no dynamic
  rendering.

---

## 8. Open questions — all resolved 2026-08-10

| # | Question | Resolution |
|---|---|---|
| 1 | Favicon colorway | Hybrid approved — `#FFD76A` body, brown straps. Shipped. |
| 2 | Repo rename | Done. `bowdensw/bowdensw.github.io`, basePath removed. |
| 3 | Landing bio | Spencer will rewrite later. Current copy stands for now. |
| 4 | Skill tree copy | Claude drafts from résumé and projects; Spencer edits. |
| 5 | PxlKit licensing | Cleared — free to use, attribution required. |
| 6 | Show audio rights | Deferred to v2. |

Remaining local task for Spencer: rename the working directory to match the repo.

```bash
mv ~/Documents/spencerbowden.github.io ~/Documents/bowdensw.github.io
```

Then reconnect the folder in Cowork. The git remote already points at the new repo, so
nothing else changes.
