# CLAUDE.md — spencerbowden.github.io

Personal portfolio. Next.js 16 (App Router) + React 19 + Tailwind v4, statically exported
to GitHub Pages. No database, no backend, no API routes — everything is front-end.

Read `docs/REVAMP-SPEC.md` before making design or architecture decisions. It is the
source of truth for tokens, IA, and library choices.

---

## Always do first

- Read `docs/REVAMP-SPEC.md`.
- Read `HANDBOOK.md` — the stack, the file tree, the patterns, how to edit each page,
  and a Traps section listing every constraint that has already cost a debugging session.
- Check `public/` for existing assets before generating new ones. Do not use placeholders
  where a real asset exists.
- Work through `docs/TODO.md` in order. The phases are sequenced deliberately.

## Stack constraints — do not violate

- **`output: "export"` is set.** No server actions, no route handlers, no `dynamic`,
  no server-side data fetching, no middleware. If a feature needs a backend, it needs a
  third-party service instead.
- **Tailwind v4 — there is no `tailwind.config.ts`.** Custom colors, fonts, and spacing go
  in the `@theme` block in `app/globals.css`. Do not create a config file.
- **No basePath.** This is a GitHub *user* page at `https://bowdensw.github.io/`, served
  from the domain root. `basePath` and `assetPrefix` were removed deliberately — do not
  reintroduce them. Next prefixes its own JS and CSS but *not* raw `<img src="/...">`,
  so a basePath silently 404s every image, logo, sprite, and PDF in production. Root-
  relative asset paths (`/images/me.jpg`) are correct as written.
- Fonts load via `next/font/google` in `app/layout.tsx`. Do not add `<link>` tags or
  `@import` font URLs.

## Commands

```bash
npm run dev      # dev server, localhost:3000
npm run build    # static export to out/
npm run lint
npm run deploy   # builds, then gh-pages -d out
```

Never start a second dev server if one is running.

## Screenshot workflow

Take screenshots from `http://localhost:3000` — never a `file:///` URL. After
screenshotting, read the PNG back and compare against the reference. Do at least two
comparison rounds. Stop only when no visible differences remain.

When comparing, be specific: "heading is 32px, reference shows ~24px", "card gap is 16px,
should be 24px". Check spacing, font size/weight/line-height, exact hex colors, alignment,
border-radius, shadows, image sizing.

## Reference images

- If given a reference: match layout, spacing, typography, and color exactly. Do not
  improve it, do not add sections, do not add features it doesn't show.
- If not: design from scratch against the guardrails below.

## File layout

```
app/
  layout.tsx           root layout, fonts, <SiteNav>
  globals.css          @theme tokens live here
  page.tsx             landing
  technical/           About / Projects / Skills
  musical/             About / Shows / Mainstage
  resume/
  contact/
components/            app-wide shared components (SiteNav, etc.)
lib/                   helpers (basePath, clipboard, cn)
public/                images, logos, sprites, resume.pdf
docs/                  spec, design brief, todo
```

Section-specific components live under that section's folder. Anything used by two or
more sections moves to `components/`.

---

## Design guardrails

**Colors.** Never use default Tailwind palette values (`indigo-500`, `blue-600`, etc.).
The `@theme` block in `globals.css` is the entire palette. `#FFD76A` and `#87BFA5` fail
AA as text — use their `-deep` variants whenever the color carries text.

**Icons.** Never any emoji. Anywhere. Not in UI, not in data files, not in headings.
Tabler outline icons, PxlKit pixel icons, or hand-made SVG.

**Typography.** Never the same family for headings and body on a page. Tight tracking
(`-0.03em`) on large headings, `line-height: 1.7` on body. No hardcoded
`font-family: Georgia` / `monospace` in components — use the tokens.

**Animation.** Only `transform` and `opacity`. Never `transition-all`. Spring-style
easing. Always honor `prefers-reduced-motion` — this site leans on float and pulse
effects.

**Interactive states.** Every clickable element needs hover, `focus-visible`, and active.
No exceptions.

**Shadows.** Never flat `shadow-md`. Layered, color-tinted, low opacity.

**Depth.** Surfaces layer: page → card → floating. Not everything on one z-plane.

**Spacing.** 4px scale — `4 8 12 16 24 32 48 64 96`. Not arbitrary Tailwind steps.

**Gradients.** Sparingly. The current skill-tree backdrop stacks eight radial gradients
and reads as mud — that's the anti-pattern.

**Mobile-first.** Every page needs a mobile story, including the skill tree.

## Hard rules

- No emoji
- No `transition-all`
- No default Tailwind blue/indigo as a primary color
- No `tailwind.config.ts` (v4)
- No server actions or API routes (static export)
- No raw `<img src="/...">` without basePath handling
- Do not add sections or features not in the spec
- Do not stop after one screenshot pass

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
