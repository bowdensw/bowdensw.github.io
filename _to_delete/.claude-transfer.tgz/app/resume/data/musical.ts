/**
 * The musical résumé. Same shape as ./resume so the two share card primitives —
 * the only structural difference is that credits arrive in named groups rather
 * than as one flat list, because a theatre résumé is read by department.
 *
 * Credits are the /musical page's `credits.ts` re-cut by department. When a show
 * is added there, add it here too; the two lists are deliberately separate
 * because the résumé selects and the credits page is complete.
 */

export const profile = {
  name: "Spencer Bowden",
  title: "Music Director · Pianist · Conductor",
  email: "spencerbowden337@gmail.com",
  phone: "(513) 503-9631",
  phoneHref: "tel:+15135039631",
  site: "bowdensw.github.io/musical",
  siteHref: "/musical",
};

export const summary =
  "Nashville-based music director, pianist, arranger, and vocal coach. Classically trained and equally at home on a rock keys rig, with a focus on musical theatre — classics and new works alike.";

export const training = {
  school: "Vanderbilt University, Peabody College — Nashville, TN",
  degree:
    "Bachelor of Science: Cognitive Studies, Computer Science, Minor in Music (Piano Performance Concentration)",
  honors: "GPA: 3.88 · Dean's List, all semesters attended",
  dates: "2022 – 2026",
  study: [
    { sub: "Classical piano", text: "Jama Reagan" },
    { sub: "Collaborative piano", text: "Jennifer McGuire" },
  ],
};

/** A group is either one line of skills or a set of labelled sub-lines. */
export type SkillGroup = {
  label: string;
  items: string | { sub: string; text: string }[];
};

export const skillGroups: SkillGroup[] = [
  {
    label: "Music Direction",
    items:
      "Vocal rehearsals, pit orchestra rehearsals, conducting from the keyboard and the podium, score preparation, artistic-team collaboration",
  },
  {
    label: "Keyboard",
    items: [
      {
        sub: "Piano",
        text: "classical, collaborative, rehearsal accompaniment, sight-reading",
      },
      { sub: "Keys / Synth", text: "pit keyboard books, MainStage patches" },
      { sub: "Percussion", text: "instruction and arranging" },
    ],
  },
  {
    label: "Voice",
    items:
      "Intermediate musical theatre technique, vocal health, sectional and group instruction",
  },
  {
    label: "Production",
    items: "QLab, MainStage, arranging, stage management, producing",
  },
];

export type CreditGroup = {
  label: string;
  credits: {
    title: string;
    year: string;
    role: string;
    organization: string;
    lead: string;
  }[];
};

export const creditGroups: CreditGroup[] = [
  {
    label: "Music Direction",
    credits: [
      {
        title: "Falsettos",
        year: "2026",
        role: "Music Director, Rehearsal Accompanist, Piano/Conductor, Producer",
        organization: "Vanderbilt Immersion",
        lead: "Advisor: Dr. Ibby Cizmar",
      },
      {
        title: "Into the Woods",
        year: "2026",
        role: "Music Director, Rehearsal Accompanist, Piano",
        organization: "Vanderbilt Off-Broadway",
        lead: "Director: Alyssa Newson",
      },
      {
        title: "Natasha, Pierre, and the Great Comet of 1812",
        year: "2025",
        role: "Music Director, Rehearsal Accompanist, Piano/Conductor, QLab",
        organization: "Vanderbilt Off-Broadway",
        lead: "Director: Isabella Lough",
      },
      {
        title: "Chicago",
        year: "2024",
        role: "Music Director, Rehearsal Accompanist, Piano/Conductor",
        organization: "Vanderbilt Off-Broadway",
        lead: "Director: Ethan Blevins",
      },
    ],
  },
  {
    label: "Pit & Accompaniment",
    credits: [
      {
        title: "Merrily We Roll Along",
        year: "2026",
        role: "Piano/Synth",
        organization: "Henderson Performing Arts Community",
        lead: "MD: Trey Lundquist",
      },
      {
        title: "Come From Away",
        year: "2026",
        role: "Keys",
        organization: "The Larry Keeton Theatre",
        lead: "MD: Trey Lundquist",
      },
      {
        title: "Ride the Cyclone",
        year: "2026",
        role: "Synthesizer",
        organization: "Vanderbilt Off-Broadway",
        lead: "MD: Lalima Sharan",
      },
      {
        title: "Company",
        year: "2025",
        role: "Rehearsal Accompanist, Piano",
        organization: "Vanderbilt Off-Broadway",
        lead: "MD: Matthew Marcus",
      },
      {
        title: "CCM Musical Theatre Intensive",
        year: "2023, 2024",
        role: "Session Accompanist",
        organization: "Univ. of Cincinnati College-Conservatory of Music",
        lead: "Director: Dee Anne Bryll",
      },
      {
        title: "The Last Five Years",
        year: "2023",
        role: "Rehearsal Accompanist, Piano",
        organization: "Vanderbilt Immersion",
        lead: "Project Lead: Will Henke",
      },
    ],
  },
  {
    label: "Staging & Production",
    credits: [
      {
        title: "An American Soldier's Tale: Vonnegut and Stravinsky",
        year: "2024",
        role: "Staging Director",
        organization: "Vanderbilt Immersion",
        lead: "Project Lead: Paxson Amy",
      },
      {
        title: "Heathers: The Musical",
        year: "2024",
        role: "Stage Manager",
        organization: "Vanderbilt Off-Broadway",
        lead: "Director: Jakob Heiser",
      },
      {
        title: "Violet",
        year: "2023",
        role: "Assistant Stage Manager",
        organization: "Vanderbilt Off-Broadway",
        lead: "Director: Brianna Stewart",
      },
    ],
  },
];

export const teaching = [
  {
    org: "University of Cincinnati, College-Conservatory of Music — Cincinnati, OH",
    role: "Session Accompanist, Musical Theatre Intensive",
    dates: "2023, 2024",
    note: "Director: Dee Anne Bryll",
    bullets: [
      "Played daily technique, repertoire, and audition sessions across two summer intensives, sight-reading student book cuts on request.",
    ],
  },
  {
    org: "Columbus Children's Theatre — Columbus, OH",
    role: "Music & Vocals Instructor",
    dates: "2024",
    note: "Mean Girls Jr. Camp · Education Coordinator: Kate Mason",
    bullets: [
      "Taught music and vocals to a youth camp cast, running sectionals and accompanying rehearsals through to performance.",
    ],
  },
  {
    org: "Wyoming High School — Wyoming, OH",
    role: "Percussion Instructor & Arranger",
    dates: "",
    note: null,
    bullets: [
      "Instructed the percussion section and wrote arrangements for the ensemble's book.",
    ],
  },
];

export const leadership = {
  org: "Vanderbilt Off-Broadway (VOB) — Nashville, TN",
  roles: [
    {
      title: "President",
      dates: "2025 – 2026",
      note: null,
      bullets: [
        "Led 12 executive board members to supervise the daily operations and successful musical productions of the 100+ member organization.",
        "Oversaw officer selections, interviews, and artistic team training.",
        "Maintained VOB's constitution and campus presence by coordinating performances and ensuring annual registration.",
      ],
    },
    {
      title: "Music Director",
      dates: "2024 – 2026",
      note: "Chicago (2024) · Natasha, Pierre, and the Great Comet of 1812 (2024–25) · Into the Woods (2025–26) · Falsettos (2026)",
      bullets: [
        "Led vocal rehearsals and office hours with show casts, focusing on intermediate musical theatre vocal technique and good vocal health.",
        "Arranged and led pit orchestra rehearsals with 10+ instrumentalists, and played and conducted during performances.",
        "Collaborated with the artistic team to ensure the show's musical facets fit the director's vision, composer's intentions, and production's goals.",
      ],
    },
  ],
};
